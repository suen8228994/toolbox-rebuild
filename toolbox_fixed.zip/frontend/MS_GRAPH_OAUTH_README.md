# 微软账号授权工具使用说明

## 🎯 功能概述

这个工具使用**设备代码流(Device Code Flow)**获取Microsoft账号的refresh_token，可用于访问Microsoft Graph API（如邮箱读取等）。

## 📋 功能特点

- ✅ 使用OAuth 2.0设备代码流，无需密码
- ✅ 支持Outlook/Hotmail等个人Microsoft账号
- ✅ 自动打开授权网页
- ✅ 实时轮询获取token
- ✅ 本地保存授权历史
- ✅ 支持自定义Client ID和权限范围

## 🚀 使用步骤

### 1. 打开工具
在"其他工具"面板中，点击"🔑 微软账号授权"工具卡片

### 2. 配置参数

**Client ID (必填)**
- 默认值：`1d08522d-70bb-4128-8684-449f9a2efa5f` (示例应用)
- 建议：在Azure AD中创建自己的应用并使用自己的Client ID

**邮箱地址 (可选)**
- 用于标识此token，会包含在输出中
- 格式示例：`example@outlook.com`

**OAuth Scope (可选)**
- 默认：`offline_access https://graph.microsoft.com/Mail.Read`
- offline_access：允许获取refresh_token
- Mail.Read：读取邮件权限

### 3. 开始授权

1. 点击"开始授权"按钮
2. 工具会显示授权提示信息，包含：
   - 授权网址（会自动打开）
   - 设备验证码
3. 在打开的浏览器中：
   - 输入显示的设备验证码
   - 登录你的Microsoft账号
   - 同意权限请求
4. 授权成功后，refresh_token会自动显示在输出框中

### 4. 保存Token

授权成功后，你可以：
- **复制Token**：点击"复制Token"按钮复制到剪贴板
- **保存到文件**：点击"保存到文件"按钮下载为txt文件
- **查看历史**：在"授权历史记录"区域查看之前的授权

## 📝 输出格式

生成的token格式为：
```
email|clientId|refresh_token
```

示例：
```
example@outlook.com|1d08522d-70bb-4128-8684-449f9a2efa5f|0.AXEA...很长的token字符串
```

## 🔧 技术实现

### 文件结构
```
frontend/
├── src/
│   ├── utils/
│   │   └── msGraphDeviceCode.js    # OAuth核心逻辑
│   ├── preload.js                   # Electron IPC桥接
│   └── renderer/
│       └── js/
│           └── tools.js             # UI界面代码
```

### 核心函数

**startDeviceCodeFlow()**
- 请求Microsoft OAuth设备代码
- 返回设备代码、验证URL和用户代码

**pollForRefreshToken()**
- 轮询检查用户是否完成授权
- 成功后返回refresh_token

### Azure AD应用配置

如需使用自己的Client ID，需要在Azure AD中：

1. 注册新应用
2. 配置平台：添加"移动和桌面应用程序"
3. 设置重定向URI：`https://login.microsoftonline.com/common/oauth2/nativeclient`
4. 启用"允许公共客户端流"
5. 配置API权限：
   - `offline_access` (Microsoft Graph)
   - `Mail.Read` (Microsoft Graph)

## ⚠️ 注意事项

1. **Client ID安全**
   - 示例Client ID仅供测试使用
   - 生产环境请使用自己的Azure AD应用

2. **Token安全**
   - refresh_token非常敏感，请妥善保管
   - 不要分享或提交到代码仓库

3. **授权超时**
   - 设备代码默认15分钟内有效
   - 超时后需重新开始授权流程

4. **权限范围**
   - 根据实际需求修改scope
   - 某些权限可能需要管理员同意

## 🐛 故障排查

### 问题：点击"开始授权"没有反应
**解决**：检查浏览器控制台错误信息，确保axios已正确安装

### 问题：授权一直等待，无法完成
**解决**：
- 确认已在浏览器中完成登录和授权
- 检查网络连接
- 尝试重新开始授权流程

### 问题：提示"refresh_token不存在"
**解决**：
- 确认scope中包含`offline_access`
- 检查Azure AD应用配置是否正确

## 📚 相关文档

- [Microsoft Identity Platform - Device Code Flow](https://learn.microsoft.com/en-us/azure/active-directory/develop/v2-oauth2-device-code)
- [Microsoft Graph API](https://learn.microsoft.com/en-us/graph/overview)
- [Azure AD App Registration](https://learn.microsoft.com/en-us/azure/active-directory/develop/quickstart-register-app)

## 🎉 完成

现在你可以使用获取的refresh_token来访问Microsoft Graph API，实现邮箱自动化等功能！
