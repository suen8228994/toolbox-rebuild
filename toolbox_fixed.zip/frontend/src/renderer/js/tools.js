// Tool definitions and content generator
const toolDefinitions = {
    'amazon-check-live': {
        title: '🔍 亚马逊批量测活',
        html: `
            <div class="tool-content">
                <div class="section">
                    <label>账号文件 (格式: email----password 或上传文�?</label>
                    <div style="display: flex; gap: 10px; margin-bottom: 10px;">
                        <input type="file" id="account-file-input" accept=".txt" style="flex: 1;">
                        <button id="clear-accounts-btn" class="secondary-btn">清空</button>
                    </div>
                    <textarea id="accounts-input" rows="10" placeholder="email1----password1&#10;email2----password2&#10;..."></textarea>
                    <div style="margin-top: 5px; color: #666; font-size: 12px;">
                        <span id="account-count">账号数量: 0</span>
                    </div>
                </div>
                
                <div class="section">
                    <label>代理配置</label>
                    <div style="display: flex; gap: 10px; margin-bottom: 10px;">
                        <select id="proxy-type" style="flex: 1;">
                            <option value="none">不使用代�?/option>
                            <option value="http">HTTP代理</option>
                            <option value="socks5">SOCKS5代理</option>
                        </select>
                        <input type="file" id="proxy-file-input" accept=".txt" style="flex: 1;">
                    </div>
                    <textarea id="proxy-input" rows="4" placeholder="代理格式: host:port:username:password&#10;每行一个代�?></textarea>
                    <div style="margin-top: 5px; color: #666; font-size: 12px;">
                        <span id="proxy-count">代理数量: 0</span>
                    </div>
                </div>

                <div class="section">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label>并发数量</label>
                            <input type="number" id="thread-count" value="5" min="1" max="50">
                        </div>
                        <div>
                            <label>超时时间(�?</label>
                            <input type="number" id="timeout-seconds" value="30" min="10" max="120">
                        </div>
                        <div>
                            <label>重试次数</label>
                            <input type="number" id="retry-count" value="2" min="0" max="5">
                        </div>
                        <div>
                            <label>延迟(毫秒)</label>
                            <input type="number" id="delay-ms" value="1000" min="0" max="10000" step="100">
                        </div>
                    </div>
                </div>

                <div class="section">
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <button id="start-check-btn" class="primary-btn">开始测�?/button>
                        <button id="stop-check-btn" class="secondary-btn" disabled>停止</button>
                        <button id="export-alive-btn" class="secondary-btn">导出存活账号</button>
                        <button id="export-dead-btn" class="secondary-btn">导出失效账号</button>
                        <button id="clear-results-btn" class="secondary-btn">清空结果</button>
                    </div>
                </div>

                <div class="section">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <h4>测活结果</h4>
                        <div style="font-size: 12px; color: #666;">
                            <span id="alive-count" style="color: #4CAF50;">存活: 0</span> |
                            <span id="dead-count" style="color: #f44336;">失效: 0</span> |
                            <span id="total-checked">已检�? 0</span>
                        </div>
                    </div>
                    <div id="check-results" class="results-container" style="max-height: 400px; overflow-y: auto;"></div>
                </div>
            </div>

            <script>
                (function() {
                    const startBtn = document.getElementById('start-check-btn');
                    const stopBtn = document.getElementById('stop-check-btn');
                    const resultsDiv = document.getElementById('check-results');
                    const accountsInput = document.getElementById('accounts-input');
                    const accountFileInput = document.getElementById('account-file-input');
                    const proxyFileInput = document.getElementById('proxy-file-input');
                    const proxyInput = document.getElementById('proxy-input');
                    const clearAccountsBtn = document.getElementById('clear-accounts-btn');
                    const exportAliveBtn = document.getElementById('export-alive-btn');
                    const exportDeadBtn = document.getElementById('export-dead-btn');
                    const clearResultsBtn = document.getElementById('clear-results-btn');
                    
                    let isRunning = false;
                    let aliveAccounts = [];
                    let deadAccounts = [];
                    let aliveCount = 0;
                    let deadCount = 0;
                    let totalChecked = 0;

                    // 更新账号数量
                    function updateAccountCount() {
                        const count = accountsInput.value.trim().split('\\n').filter(line => line.trim()).length;
                        document.getElementById('account-count').textContent = '账号数量: ' + count;
                    }

                    // 更新代理数量
                    function updateProxyCount() {
                        const count = proxyInput.value.trim().split('\\n').filter(line => line.trim()).length;
                        document.getElementById('proxy-count').textContent = '代理数量: ' + count;
                    }

                    // 更新统计信息
                    function updateStats() {
                        document.getElementById('alive-count').textContent = '存活: ' + aliveCount;
                        document.getElementById('dead-count').textContent = '失效: ' + deadCount;
                        document.getElementById('total-checked').textContent = '已检�? ' + totalChecked;
                    }

                    accountsInput.addEventListener('input', updateAccountCount);
                    proxyInput.addEventListener('input', updateProxyCount);

                    // 账号文件上传
                    accountFileInput.addEventListener('change', (e) => {
                        const file = e.target.files[0];
                        if (file) {
                            const reader = new FileReader();
                            reader.onload = (event) => {
                                accountsInput.value = event.target.result;
                                updateAccountCount();
                            };
                            reader.readAsText(file);
                        }
                    });

                    // 代理文件上传
                    proxyFileInput.addEventListener('change', (e) => {
                        const file = e.target.files[0];
                        if (file) {
                            const reader = new FileReader();
                            reader.onload = (event) => {
                                proxyInput.value = event.target.result;
                                updateProxyCount();
                            };
                            reader.readAsText(file);
                        }
                    });

                    // 清空账号
                    clearAccountsBtn.addEventListener('click', () => {
                        accountsInput.value = '';
                        accountFileInput.value = '';
                        updateAccountCount();
                    });

                    // 清空结果
                    clearResultsBtn.addEventListener('click', () => {
                        resultsDiv.innerHTML = '';
                        aliveAccounts = [];
                        deadAccounts = [];
                        aliveCount = 0;
                        deadCount = 0;
                        totalChecked = 0;
                        updateStats();
                    });

                    startBtn.addEventListener('click', async () => {
                        const accounts = accountsInput.value.trim();
                        const proxyType = document.getElementById('proxy-type').value;
                        const proxies = proxyInput.value.trim();
                        const threads = parseInt(document.getElementById('thread-count').value);
                        const timeout = parseInt(document.getElementById('timeout-seconds').value);
                        const retry = parseInt(document.getElementById('retry-count').value);
                        const delay = parseInt(document.getElementById('delay-ms').value);

                        if (!accounts) {
                            alert('请输入账号信�?);
                            return;
                        }

                        isRunning = true;
                        startBtn.disabled = true;
                        stopBtn.disabled = false;
                        resultsDiv.innerHTML = '<p style="color: #2196F3;">�?正在检测账�?..</p>';
                        
                        // 重置统计
                        aliveAccounts = [];
                        deadAccounts = [];
                        aliveCount = 0;
                        deadCount = 0;
                        totalChecked = 0;
                        updateStats();

                        try {
                            window.appSocket.emit('request.amazon.checkLive', {
                                accounts: accounts.split('\\n').filter(line => line.trim()),
                                proxyType: proxyType,
                                proxies: proxies ? proxies.split('\\n').filter(line => line.trim()) : [],
                                threads: threads,
                                timeout: timeout * 1000,
                                retry: retry,
                                delay: delay
                            });

                            // 清除之前的监听器
                            window.appSocket.off('backend.amazon.checkResult');
                            window.appSocket.off('backend.amazon.checkComplete');

                            window.appSocket.on('backend.amazon.checkResult', (data) => {
                                totalChecked++;
                                const resultItem = document.createElement('div');
                                resultItem.style.padding = '8px';
                                resultItem.style.marginBottom = '5px';
                                resultItem.style.borderRadius = '4px';
                                resultItem.style.fontSize = '13px';
                                
                                if (data.isAlive) {
                                    aliveCount++;
                                    aliveAccounts.push(data.account);
                                    resultItem.style.backgroundColor = '#e8f5e9';
                                    resultItem.style.borderLeft = '3px solid #4CAF50';
                                    resultItem.innerHTML = '<strong style="color: #4CAF50;">✅ 存活</strong> ' + data.account;
                                } else {
                                    deadCount++;
                                    deadAccounts.push(data.account);
                                    resultItem.style.backgroundColor = '#ffebee';
                                    resultItem.style.borderLeft = '3px solid #f44336';
                                    resultItem.innerHTML = '<strong style="color: #f44336;">❌ 失效</strong> ' + data.account + (data.message ? ' - ' + data.message : '');
                                }
                                
                                resultsDiv.appendChild(resultItem);
                                resultsDiv.scrollTop = resultsDiv.scrollHeight;
                                updateStats();
                            });

                            window.appSocket.on('backend.amazon.checkComplete', () => {
                                isRunning = false;
                                startBtn.disabled = false;
                                stopBtn.disabled = true;
                                const completeMsg = document.createElement('div');
                                completeMsg.style.padding = '10px';
                                completeMsg.style.marginTop = '10px';
                                completeMsg.style.backgroundColor = '#e3f2fd';
                                completeMsg.style.borderRadius = '4px';
                                completeMsg.style.textAlign = 'center';
                                completeMsg.style.fontWeight = 'bold';
                                completeMsg.innerHTML = '🎉 测活完成！存活: ' + aliveCount + ' | 失效: ' + deadCount + ' | 总计: ' + totalChecked;
                                resultsDiv.appendChild(completeMsg);
                            });

                        } catch (error) {
                            resultsDiv.innerHTML = '<p style="color: #f44336;">错误: ' + error.message + '</p>';
                            startBtn.disabled = false;
                            stopBtn.disabled = true;
                            isRunning = false;
                        }
                    });

                    stopBtn.addEventListener('click', () => {
                        window.appSocket.emit('request.amazon.stopCheck');
                        isRunning = false;
                        startBtn.disabled = false;
                        stopBtn.disabled = true;
                    });

                    // 导出存活账号
                    exportAliveBtn.addEventListener('click', () => {
                        if (aliveAccounts.length === 0) {
                            alert('没有存活账号可导�?);
                            return;
                        }
                        const content = aliveAccounts.join('\\n');
                        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = amazon_alive_' + Date.now() + '.txt;
                        a.click();
                        URL.revokeObjectURL(url);
                    });

                    // 导出失效账号
                    exportDeadBtn.addEventListener('click', () => {
                        if (deadAccounts.length === 0) {
                            alert('没有失效账号可导�?);
                            return;
                        }
                        const content = deadAccounts.join('\\n');
                        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = amazon_dead_' + Date.now() + '.txt;
                        a.click();
                        URL.revokeObjectURL(url);
                    });
                })();
            </script>
        `
    },

    'amazon-register': {
        title: '📝 亚马逊批量注册',
        html: `
            <div class="tool-content">
                <div class="section">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label>注册数量</label>
                            <input type="number" id="register-count" value="1" min="1" max="100">
                        </div>
                        <div>
                            <label>并发数量</label>
                            <input type="number" id="register-threads" value="3" min="1" max="10">
                        </div>
                    </div>
                </div>

                <div class="section">
                    <label>代理配置</label>
                    <div style="display: flex; gap: 10px; margin-bottom: 10px;">
                        <input type="file" id="register-proxy-file" accept=".txt" style="flex: 1;">
                        <button id="clear-register-proxies-btn" class="secondary-btn">清空</button>
                    </div>
                    <textarea id="register-proxy-input" rows="4" placeholder="host:port:username:password&#10;每行一个代�?></textarea>
                    <div style="margin-top: 5px; color: #666; font-size: 12px;">
                        <span id="register-proxy-count">代理数量: 0</span>
                    </div>
                </div>

                <div class="section">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label>邮箱类型</label>
                            <select id="email-type">
                                <option value="gmail">Gmail</option>
                                <option value="outlook">Outlook</option>
                                <option value="hotmail">Hotmail</option>
                                <option value="custom">自定�?/option>
                            </select>
                        </div>
                        <div>
                            <label>自定义后缀</label>
                            <input type="text" id="email-suffix" placeholder="@example.com" disabled>
                        </div>
                    </div>
                </div>

                <div class="section">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label>密码长度</label>
                            <input type="number" id="password-length" value="12" min="8" max="32">
                        </div>
                        <div>
                            <label>姓名类型</label>
                            <select id="name-type">
                                <option value="random">随机英文�?/option>
                                <option value="chinese">中文拼音</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="section">
                    <label>验证码接收方�?/label>
                    <select id="verification-method">
                        <option value="manual">手动输入</option>
                        <option value="api">API自动接码</option>
                    </select>
                    <input type="text" id="verification-api-key" placeholder="API密钥（如使用API接码�? style="margin-top: 10px; display: none;">
                </div>

                <div class="section">
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <button id="start-register-btn" class="primary-btn">开始注�?/button>
                        <button id="stop-register-btn" class="secondary-btn" disabled>停止</button>
                        <button id="export-accounts-btn" class="secondary-btn">导出账号</button>
                        <button id="export-failed-btn" class="secondary-btn">导出失败记录</button>
                        <button id="clear-register-results-btn" class="secondary-btn">清空结果</button>
                    </div>
                </div>

                <div class="section">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <h4>注册结果</h4>
                        <div style="font-size: 12px; color: #666;">
                            <span id="success-count" style="color: #4CAF50;">成功: 0</span> |
                            <span id="failed-count" style="color: #f44336;">失败: 0</span> |
                            <span id="total-register">总计: 0</span>
                        </div>
                    </div>
                    <div id="register-results" class="results-container" style="max-height: 400px; overflow-y: auto;"></div>
                </div>
            </div>

            <script>
                (function() {
                    const startBtn = document.getElementById('start-register-btn');
                    const stopBtn = document.getElementById('stop-register-btn');
                    const resultsDiv = document.getElementById('register-results');
                    const exportBtn = document.getElementById('export-accounts-btn');
                    const exportFailedBtn = document.getElementById('export-failed-btn');
                    const clearResultsBtn = document.getElementById('clear-register-results-btn');
                    const proxyInput = document.getElementById('register-proxy-input');
                    const proxyFileInput = document.getElementById('register-proxy-file');
                    const clearProxiesBtn = document.getElementById('clear-register-proxies-btn');
                    const emailType = document.getElementById('email-type');
                    const emailSuffix = document.getElementById('email-suffix');
                    const verificationMethod = document.getElementById('verification-method');
                    const verificationApiKey = document.getElementById('verification-api-key');
                    
                    let registeredAccounts = [];
                    let failedAttempts = [];
                    let successCount = 0;
                    let failedCount = 0;
                    let totalRegister = 0;

                    // 更新代理数量
                    function updateProxyCount() {
                        const count = proxyInput.value.trim().split('\\n').filter(line => line.trim()).length;
                        document.getElementById('register-proxy-count').textContent = '代理数量: ' + count;
                    }

                    // 更新统计信息
                    function updateStats() {
                        document.getElementById('success-count').textContent = '成功: ' + successCount;
                        document.getElementById('failed-count').textContent = '失败: ' + failedCount;
                        document.getElementById('total-register').textContent = '总计: ' + totalRegister;
                    }

                    proxyInput.addEventListener('input', updateProxyCount);

                    // 代理文件上传
                    proxyFileInput.addEventListener('change', (e) => {
                        const file = e.target.files[0];
                        if (file) {
                            const reader = new FileReader();
                            reader.onload = (event) => {
                                proxyInput.value = event.target.result;
                                updateProxyCount();
                            };
                            reader.readAsText(file);
                        }
                    });

                    // 清空代理
                    clearProxiesBtn.addEventListener('click', () => {
                        proxyInput.value = '';
                        proxyFileInput.value = '';
                        updateProxyCount();
                    });

                    // 邮箱类型切换
                    emailType.addEventListener('change', (e) => {
                        if (e.target.value === 'custom') {
                            emailSuffix.disabled = false;
                            emailSuffix.focus();
                        } else {
                            emailSuffix.disabled = true;
                            emailSuffix.value = '';
                        }
                    });

                    // 验证方式切换
                    verificationMethod.addEventListener('change', (e) => {
                        if (e.target.value === 'api') {
                            verificationApiKey.style.display = 'block';
                        } else {
                            verificationApiKey.style.display = 'none';
                        }
                    });

                    // 清空结果
                    clearResultsBtn.addEventListener('click', () => {
                        resultsDiv.innerHTML = '';
                        registeredAccounts = [];
                        failedAttempts = [];
                        successCount = 0;
                        failedCount = 0;
                        totalRegister = 0;
                        updateStats();
                    });

                    startBtn.addEventListener('click', () => {
                        const count = parseInt(document.getElementById('register-count').value);
                        const threads = parseInt(document.getElementById('register-threads').value);
                        const proxies = proxyInput.value.trim();
                        const emailTypeValue = emailType.value;
                        const customSuffix = emailSuffix.value.trim();
                        const passwordLen = parseInt(document.getElementById('password-length').value);
                        const nameType = document.getElementById('name-type').value;
                        const verificationMethodValue = verificationMethod.value;
                        const apiKey = verificationApiKey.value.trim();

                        if (!proxies) {
                            alert('请输入代理配�?);
                            return;
                        }

                        if (emailTypeValue === 'custom' && !customSuffix) {
                            alert('请输入自定义邮箱后缀');
                            return;
                        }

                        if (verificationMethodValue === 'api' && !apiKey) {
                            alert('请输入API密钥');
                            return;
                        }

                        startBtn.disabled = true;
                        stopBtn.disabled = false;
                        resultsDiv.innerHTML = '<p style="color: #2196F3;">�?正在注册账号...</p>';
                        
                        // 重置统计
                        registeredAccounts = [];
                        failedAttempts = [];
                        successCount = 0;
                        failedCount = 0;
                        totalRegister = 0;
                        updateStats();

                        // 清除之前的监听器
                        window.appSocket.off('backend.amazon.registerResult');
                        window.appSocket.off('backend.amazon.registerComplete');

                        window.appSocket.emit('request.amazon.register', {
                            count: count,
                            threads: threads,
                            proxies: proxies.split('\\n').filter(line => line.trim()),
                            emailType: emailTypeValue,
                            customSuffix: customSuffix,
                            passwordLength: passwordLen,
                            nameType: nameType,
                            verificationMethod: verificationMethodValue,
                            apiKey: apiKey
                        });

                        window.appSocket.on('backend.amazon.registerResult', (data) => {
                            totalRegister++;
                            const resultItem = document.createElement('div');
                            resultItem.style.padding = '8px';
                            resultItem.style.marginBottom = '5px';
                            resultItem.style.borderRadius = '4px';
                            resultItem.style.fontSize = '13px';
                            
                            if (data.success) {
                                successCount++;
                                registeredAccounts.push(data.account);
                                resultItem.style.backgroundColor = '#e8f5e9';
                                resultItem.style.borderLeft = '3px solid #4CAF50';
                                resultItem.innerHTML = '<strong style="color: #4CAF50;">✅ 成功</strong> ' + data.account.email + '----' + data.account.password;
                            } else {
                                failedCount++;
                                failedAttempts.push(data.error || '未知错误');
                                resultItem.style.backgroundColor = '#ffebee';
                                resultItem.style.borderLeft = '3px solid #f44336';
                                resultItem.innerHTML = '<strong style="color: #f44336;">❌ 失败</strong> ' + data.error;
                            }
                            
                            resultsDiv.appendChild(resultItem);
                            resultsDiv.scrollTop = resultsDiv.scrollHeight;
                            updateStats();
                        });

                        window.appSocket.on('backend.amazon.registerComplete', () => {
                            startBtn.disabled = false;
                            stopBtn.disabled = true;
                            const completeMsg = document.createElement('div');
                            completeMsg.style.padding = '10px';
                            completeMsg.style.marginTop = '10px';
                            completeMsg.style.backgroundColor = '#e3f2fd';
                            completeMsg.style.borderRadius = '4px';
                            completeMsg.style.textAlign = 'center';
                            completeMsg.style.fontWeight = 'bold';
                            completeMsg.innerHTML = '🎉 注册完成！成功: ' + successCount + ' | 失败: ' + failedCount + ' | 总计: ' + totalRegister;
                            resultsDiv.appendChild(completeMsg);
                        });
                    });

                    stopBtn.addEventListener('click', () => {
                        window.appSocket.emit('request.amazon.stopRegister');
                        startBtn.disabled = false;
                        stopBtn.disabled = true;
                    });

                    // 导出成功账号
                    exportBtn.addEventListener('click', () => {
                        if (registeredAccounts.length === 0) {
                            alert('没有可导出的账号');
                            return;
                        }

                        const content = registeredAccounts.map(acc => acc.email + '----' + acc.password).join('\n');
                        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = amazon_accounts_' + Date.now() + '.txt;
                        a.click();
                        URL.revokeObjectURL(url);
                    });

                    // 导出失败记录
                    exportFailedBtn.addEventListener('click', () => {
                        if (failedAttempts.length === 0) {
                            alert('没有失败记录可导�?);
                            return;
                        }

                        const content = failedAttempts.join('\\n');
                        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = amazon_failed_' + Date.now() + '.txt;
                        a.click();
                        URL.revokeObjectURL(url);
                    });
                })();
            </script>
        `
    },

    'cookie-transformer': {
        title: '🍪 Cookie转换',
        html: `
            <div class="tool-content">
                <div class="section">
                    <label>输入Cookie格式</label>
                    <select id="input-format">
                        <option value="netscape">Netscape格式</option>
                        <option value="json">JSON格式</option>
                        <option value="header">Header格式</option>
                    </select>
                </div>

                <div class="section">
                    <label>输入Cookie</label>
                    <textarea id="cookie-input" rows="10" placeholder="粘贴Cookie内容..."></textarea>
                </div>

                <div class="section">
                    <label>输出Cookie格式</label>
                    <select id="output-format">
                        <option value="netscape">Netscape格式</option>
                        <option value="json">JSON格式</option>
                        <option value="header">Header格式</option>
                    </select>
                </div>

                <div class="section">
                    <button id="transform-btn" class="primary-btn">转换</button>
                    <button id="copy-result-btn" class="secondary-btn">复制结果</button>
                </div>

                <div class="section">
                    <label>转换结果</label>
                    <textarea id="cookie-output" rows="10" readonly></textarea>
                </div>
            </div>

            <script>
                (function() {
                    const transformBtn = document.getElementById('transform-btn');
                    const copyBtn = document.getElementById('copy-result-btn');
                    const inputTextarea = document.getElementById('cookie-input');
                    const outputTextarea = document.getElementById('cookie-output');
                    const inputFormat = document.getElementById('input-format');
                    const outputFormat = document.getElementById('output-format');

                    transformBtn.addEventListener('click', () => {
                        const input = inputTextarea.value.trim();
                        if (!input) {
                            alert('请输入Cookie内容');
                            return;
                        }

                        window.appSocket.emit('request.cookie.transform', {
                            input: input,
                            inputFormat: inputFormat.value,
                            outputFormat: outputFormat.value
                        });

                        window.appSocket.once('backend.cookie.transformResult', (data) => {
                            if (data.success) {
                                outputTextarea.value = data.output;
                            } else {
                                alert('转换失败: ' + data.error);
                                outputTextarea.value = '';
                            }
                        });
                    });

                    copyBtn.addEventListener('click', () => {
                        if (!outputTextarea.value) {
                            alert('没有可复制的内容');
                            return;
                        }
                        outputTextarea.select();
                        document.execCommand('copy');
                        alert('已复制到剪贴�?);
                    });
                })();
            </script>
        `
    },

    'roxybrowser-to-hubstudio': {
        title: '🔄 Roxy转HubStudio',
        html: `
            <div class="tool-content">
                <div class="section">
                    <label>RoxyBrowser配置文件</label>
                    <input type="file" id="roxy-file-input" accept=".json,.txt">
                </div>

                <div class="section">
                    <label>或直接粘贴配�?/label>
                    <textarea id="roxy-text-input" rows="10" placeholder="粘贴RoxyBrowser配置内容..."></textarea>
                </div>

                <div class="section">
                    <button id="convert-roxy-btn" class="primary-btn">转换</button>
                    <button id="download-hubstudio-btn" class="secondary-btn" disabled>下载HubStudio配置</button>
                </div>

                <div class="section">
                    <label>转换结果预览</label>
                    <textarea id="hubstudio-preview" rows="10" readonly></textarea>
                </div>

                <div class="section">
                    <div id="conversion-status"></div>
                </div>
            </div>

            <script>
                (function() {
                    const fileInput = document.getElementById('roxy-file-input');
                    const textInput = document.getElementById('roxy-text-input');
                    const convertBtn = document.getElementById('convert-roxy-btn');
                    const downloadBtn = document.getElementById('download-hubstudio-btn');
                    const previewTextarea = document.getElementById('hubstudio-preview');
                    const statusDiv = document.getElementById('conversion-status');
                    let convertedData = null;

                    fileInput.addEventListener('change', (e) => {
                        const file = e.target.files[0];
                        if (file) {
                            const reader = new FileReader();
                            reader.onload = (event) => {
                                textInput.value = event.target.result;
                            };
                            reader.readAsText(file);
                        }
                    });

                    convertBtn.addEventListener('click', () => {
                        const input = textInput.value.trim();
                        if (!input) {
                            alert('请选择文件或粘贴配置内�?);
                            return;
                        }

                        statusDiv.innerHTML = '<p>正在转换...</p>';
                        downloadBtn.disabled = true;

                        window.appSocket.emit('request.roxy.convert', {
                            roxyConfig: input
                        });

                        window.appSocket.once('backend.roxy.convertResult', (data) => {
                            if (data.success) {
                                convertedData = data.hubstudioConfig;
                                previewTextarea.value = JSON.stringify(convertedData, null, 2);
                                downloadBtn.disabled = false;
                                statusDiv.innerHTML = '<p class="success">✅ 转换成功！</p>';
                            } else {
                                statusDiv.innerHTML = '<p class="error">❌ 转换失败: ' + data.error + '</p>';
                                previewTextarea.value = '';
                                downloadBtn.disabled = true;
                            }
                        });
                    });

                    downloadBtn.addEventListener('click', () => {
                        if (!convertedData) return;

                        const blob = new Blob([JSON.stringify(convertedData, null, 2)], { type: 'application/json' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = hubstudio_config_' + Date.now() + '.json;
                        a.click();
                        URL.revokeObjectURL(url);
                    });
                })();
            </script>
        `
    },

    'qrcode-generation': {
        title: '📱 小火箭二维码生成',
        html: `
            <div class="tool-content">
                <div class="section">
                    <label>代理配置</label>
                    <textarea id="proxy-config-input" rows="6" placeholder="输入Shadowrocket配置链接或文�?.."></textarea>
                </div>

                <div class="section">
                    <label>二维码大�?/label>
                    <select id="qr-size">
                        <option value="200">�?(200x200)</option>
                        <option value="300" selected>�?(300x300)</option>
                        <option value="400">�?(400x400)</option>
                    </select>
                </div>

                <div class="section">
                    <button id="generate-qr-btn" class="primary-btn">生成二维�?/button>
                    <button id="download-qr-btn" class="secondary-btn" disabled>下载二维�?/button>
                </div>

                <div class="section">
                    <div id="qrcode-container" style="text-align: center; min-height: 320px; display: flex; align-items: center; justify-content: center;">
                        <p style="color: #888;">二维码将在这里显�?/p>
                    </div>
                </div>
            </div>

            <script>
                (function() {
                    const generateBtn = document.getElementById('generate-qr-btn');
                    const downloadBtn = document.getElementById('download-qr-btn');
                    const configInput = document.getElementById('proxy-config-input');
                    const sizeSelect = document.getElementById('qr-size');
                    const container = document.getElementById('qrcode-container');
                    let currentQRDataURL = null;

                    generateBtn.addEventListener('click', () => {
                        const config = configInput.value.trim();
                        if (!config) {
                            alert('请输入代理配�?);
                            return;
                        }

                        const size = parseInt(sizeSelect.value);
                        container.innerHTML = '<p>正在生成二维�?..</p>';
                        downloadBtn.disabled = true;

                        window.appSocket.emit('request.qrcode.generate', {
                            config: config,
                            size: size
                        });

                        window.appSocket.once('backend.qrcode.generateResult', (data) => {
                            if (data.success) {
                                currentQRDataURL = data.qrCodeDataURL;
                                container.innerHTML = '<img src="' + data.qrCodeDataURL + '" alt="QR Code" style="max-width: 100%;">';
                                downloadBtn.disabled = false;
                            } else {
                                container.innerHTML = '<p class="error">生成失败: ' + data.error + '</p>';
                                downloadBtn.disabled = true;
                            }
                        });
                    });

                    downloadBtn.addEventListener('click', () => {
                        if (!currentQRDataURL) return;

                        const a = document.createElement('a');
                        a.href = currentQRDataURL;
                        a.download = shadowrocket_qr_' + Date.now() + '.png;
                        a.click();
                    });
                })();
            </script>
        `
    },

    'microsoft-email': {
        title: '📧 微软邮箱取验证码',
        html: `
            <div class="tool-content">
                <div class="section">
                    <label>邮箱账号</label>
                    <input type="text" id="ms-email" placeholder="your-email@outlook.com">
                </div>

                <div class="section">
                    <label>邮箱密码</label>
                    <input type="password" id="ms-password" placeholder="密码">
                </div>

                <div class="section">
                    <label>搜索关键�?(可�?</label>
                    <input type="text" id="search-keyword" placeholder="验证�?>
                </div>

                <div class="section">
                    <label>获取邮件数量</label>
                    <input type="number" id="email-count" value="10" min="1" max="50">
                </div>

                <div class="section">
                    <button id="fetch-emails-btn" class="primary-btn">获取验证�?/button>
                    <button id="refresh-emails-btn" class="secondary-btn">刷新</button>
                </div>

                <div class="section">
                    <h4>邮件列表</h4>
                    <div id="emails-list" class="results-container"></div>
                </div>
            </div>

            <script>
                (function() {
                    const fetchBtn = document.getElementById('fetch-emails-btn');
                    const refreshBtn = document.getElementById('refresh-emails-btn');
                    const emailsList = document.getElementById('emails-list');

                    function fetchEmails() {
                        const email = document.getElementById('ms-email').value.trim();
                        const password = document.getElementById('ms-password').value.trim();
                        const keyword = document.getElementById('search-keyword').value.trim();
                        const count = parseInt(document.getElementById('email-count').value);

                        if (!email || !password) {
                            alert('请输入邮箱和密码');
                            return;
                        }

                        emailsList.innerHTML = '<p>正在获取邮件...</p>';

                        window.appSocket.emit('request.microsoft.fetchEmails', {
                            email: email,
                            password: password,
                            keyword: keyword,
                            count: count
                        });

                        window.appSocket.once('backend.microsoft.emailsResult', (data) => {
                            if (data.success) {
                                if (data.emails.length === 0) {
                                    emailsList.innerHTML = '<p>未找到相关邮�?/p>';
                                } else {
                                    emailsList.innerHTML = '';
                                    data.emails.forEach((email, index) => {
                                        const emailItem = document.createElement('div');
                                        emailItem.className = 'result-item';
                                        emailItem.innerHTML = 
                                            '<strong>[' + (index + 1) + '] ' + email.subject + '</strong><br>' +
                                            '<small>发件人: ' + email.from + '</small><br>' +
                                            '<small>时间: ' + email.date + '</small><br>' +
                                            '<div style="margin-top: 8px; padding: 8px; background: #f5f5f5; border-radius: 4px;">' +
                                                (email.code || email.preview) +
                                            '</div>';
                                        emailsList.appendChild(emailItem);
                                    });
                                }
                            } else {
                                emailsList.innerHTML = '<p class="error">获取失败: ' + data.error + '</p>';
                            }
                        });
                    }

                    fetchBtn.addEventListener('click', fetchEmails);
                    refreshBtn.addEventListener('click', fetchEmails);
                })();
            </script>
        `
    },

    
    'hotmail-batch-register': {
        title: '📧 Hotmail批量注册',
        html: `
            <div class="tool-content">
                <div class="section">
                    <h3>批量注册 Outlook / Hotmail 邮箱并获取 Token</h3>
                    <p style="color: #888; font-size: 14px; margin-bottom: 20px;">
                        自动批量注册邮箱账号，并通过 Microsoft Graph Device Code Flow 获取每个账号的 refresh_token。
                        该功能完全在本地执行，不依赖后端服务。
                    </p>
                </div>

                <!-- 配置区域 -->
                <div class="section">
                    <h4>⚙️ 注册配置</h4>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label>注册数量</label>
                            <input type="number" id="batch-count-input" min="1" value="5" placeholder="例如：10" />
                        </div>
                        <div>
                            <label>并发数</label>
                            <input type="number" id="batch-concurrency-input" min="1" max="10" value="3" />
                            <small style="display:block;color:#999;">建议 1–5，过高容易被风控</small>
                        </div>
                        <div>
                            <label>邮箱域名</label>
                            <select id="batch-email-domain">
                                <option value="outlook.com">outlook.com</option>
                                <option value="hotmail.com">hotmail.com</option>
                                <option value="outlook.de">outlook.de</option>
                                <option value="custom">自定义后缀</option>
                            </select>
                        </div>
                        <div>
                            <label>自定义后缀</label>
                            <input type="text" id="batch-email-custom-domain" placeholder="例如：mydomain.com，不要带 @" />
                            <small style="display:block;color:#999;">仅当上方选择“自定义后缀”时生效</small>
                        </div>
                    </div>
                </div>

                <!-- 代理配置 -->
                <div class="section">
                    <h4>🌐 代理设置（可选）</h4>
                    <div style="margin-bottom:10px;">
                        <input type="file" id="batch-proxy-file" accept=".txt" />
                        <button id="btn-clear-batch-proxy" class="secondary-btn">清空代理</button>
                        <small style="display:block;color:#999;margin-top:4px;">
                            每行一个代理，格式：host:port 或 host:port:username:password
                        </small>
                    </div>
                    <textarea id="batch-proxy-input" rows="4" placeholder="在此粘贴代理，一行一个"></textarea>
                    <div style="margin-top: 5px; color: #666; font-size: 12px;">
                        当前代理数量：<span id="batch-proxy-count">0</span>
                    </div>
                </div>

                <!-- 按钮区域 -->
                <div class="section">
                    <div style="display:flex;flex-wrap:wrap;gap:10px;">
                        <button id="btn-start-batch-register" class="primary-btn">🚀 开始批量注册</button>
                        <button id="btn-stop-batch-register" class="secondary-btn" disabled>⏹️ 停止</button>
                        <button id="btn-export-batch-tokens" class="secondary-btn">📥 导出 Token 文件</button>
                        <button id="btn-clear-batch-results" class="secondary-btn">🗑️ 清空结果</button>
                    </div>
                </div>

                <!-- 进度统计 -->
                <div class="section">
                    <div style="
                        display:flex;
                        justify-content:space-between;
                        gap:15px;
                        padding:12px 18px;
                        border-radius:10px;
                        background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);
                        color:#fff;
                        font-size:13px;
                    ">
                        <div style="flex:1;text-align:center;">
                            <div id="batch-total-count" style="font-size:24px;font-weight:bold;">0</div>
                            <div>总数</div>
                        </div>
                        <div style="flex:1;text-align:center;">
                            <div id="batch-success-count" style="font-size:24px;font-weight:bold;color:#4caf50;">0</div>
                            <div>成功</div>
                        </div>
                        <div style="flex:1;text-align:center;">
                            <div id="batch-failed-count" style="font-size:24px;font-weight:bold;color:#ff9800;">0</div>
                            <div>失败</div>
                        </div>
                        <div style="flex:1;text-align:center;">
                            <div id="batch-token-count" style="font-size:24px;font-weight:bold;color:#ffc107;">0</div>
                            <div>已获取 Token</div>
                        </div>
                    </div>
                </div>

                <!-- 日志输出 -->
                <div class="section">
                    <h4>📋 实时日志</h4>
                    <div id="batch-log-container" style="
                        max-height:220px;
                        overflow-y:auto;
                        padding:10px;
                        border-radius:8px;
                        background:rgba(0,0,0,0.05);
                        font-family:Consolas, Menlo, monospace;
                        font-size:12px;
                    "></div>
                </div>

                <!-- 结果列表 -->
                <div class="section">
                    <h4>✅ 成功账号列表（含 Token）</h4>
                    <div id="batch-results-container" style="
                        max-height:260px;
                        overflow-y:auto;
                        padding:10px;
                        border-radius:8px;
                        background:rgba(0,0,0,0.03);
                        font-family:Consolas, Menlo, monospace;
                        font-size:12px;
                    ">
                        <p style="color:#888;text-align:center;">暂无数据</p>
                    </div>
                </div>
            </div>

            <script>
                (function () {
                    console.log('=== Hotmail 批量注册工具脚本初始化 ===');

                    const btnStart = document.getElementById('btn-start-batch-register');
                    const btnStop = document.getElementById('btn-stop-batch-register');
                    const btnExport = document.getElementById('btn-export-batch-tokens');
                    const btnClear = document.getElementById('btn-clear-batch-results');
                    const btnClearProxy = document.getElementById('btn-clear-batch-proxy');

                    const countInput = document.getElementById('batch-count-input');
                    const concurrencyInput = document.getElementById('batch-concurrency-input');
                    const domainSelect = document.getElementById('batch-email-domain');
                    const customDomainInput = document.getElementById('batch-email-custom-domain');
                    const proxyFileInput = document.getElementById('batch-proxy-file');
                    const proxyInput = document.getElementById('batch-proxy-input');
                    const proxyCountSpan = document.getElementById('batch-proxy-count');

                    const logContainer = document.getElementById('batch-log-container');
                    const resultsContainer = document.getElementById('batch-results-container');

                    const totalSpan = document.getElementById('batch-total-count');
                    const successSpan = document.getElementById('batch-success-count');
                    const failedSpan = document.getElementById('batch-failed-count');
                    const tokenSpan = document.getElementById('batch-token-count');

                    if (!btnStart) {
                        console.error('未找到 Hotmail 批量注册的开始按钮，脚本终止。');
                        return;
                    }

                    let isRunning = false;
                    let stats = { total: 0, success: 0, failed: 0, token: 0 };
                    let successfulAccounts = [];

                    function updateStats() {
                        totalSpan.textContent = stats.total;
                        successSpan.textContent = stats.success;
                        failedSpan.textContent = stats.failed;
                        tokenSpan.textContent = stats.token;
                    }

                    function addLog(message, type) {
                        const time = new Date().toLocaleTimeString();
                        const colorMap = {
                            info: '#61afef',
                            success: '#98c379',
                            error: '#e06c75',
                            warning: '#e5c07b'
                        };
                        const line = document.createElement('div');
                        line.style.marginBottom = '4px';
                        line.style.color = colorMap[type] || '#ccc';
                        line.textContent = '[' + time + '] ' + message;
                        logContainer.appendChild(line);
                        logContainer.scrollTop = logContainer.scrollHeight;
                    }

                    function getProxies() {
                        const lines = proxyInput.value
                            .split(/\r?\n/)
                            .map(l => l.trim())
                            .filter(Boolean);
                        proxyCountSpan.textContent = String(lines.length);
                        return lines;
                    }

                    // 代理文件导入
                    if (proxyFileInput) {
                        proxyFileInput.addEventListener('change', function (e) {
                            const file = e.target.files && e.target.files[0];
                            if (!file) return;
                            const reader = new FileReader();
                            reader.onload = function (ev) {
                                proxyInput.value = String(ev.target.result || '');
                                getProxies();
                            };
                            reader.readAsText(file);
                        });
                    }

                    if (btnClearProxy) {
                        btnClearProxy.addEventListener('click', function () {
                            proxyInput.value = '';
                            if (proxyFileInput) proxyFileInput.value = '';
                            getProxies();
                        });
                    }

                    btnStart.addEventListener('click', async function () {
                        console.log('🔍 批量注册按钮被点击');

                        if (!window.hotmailBatchAPI || !window.hotmailBatchAPI.batchRegister) {
                            alert('hotmailBatchAPI 未正确加载，请确认应用已正确打包。');
                            return;
                        }
                        if (!window.msGraphAPI || !window.msGraphAPI.startDeviceCode || !window.msGraphAPI.pollForToken) {
                            alert('msGraphAPI 未正确加载，请先配置 Microsoft Graph 模块。');
                            return;
                        }

                        if (isRunning) {
                            return;
                        }

                        const count = parseInt(countInput.value, 10) || 0;
                        if (!count || count <= 0) {
                            alert('请输入有效的注册数量');
                            return;
                        }

                        let concurrency = parseInt(concurrencyInput.value, 10) || 3;
                        if (concurrency < 1) concurrency = 1;

                        let domain = domainSelect.value || 'outlook.com';
                        if (domain === 'custom') {
                            const custom = customDomainInput.value.trim().replace(/^@+/, '');
                            if (!custom) {
                                alert('请选择域名或填写自定义后缀');
                                return;
                            }
                            domain = custom;
                        }

                        const proxies = getProxies();

                        isRunning = true;
                        stats = { total: count, success: 0, failed: 0, token: 0 };
                        successfulAccounts = [];
                        logContainer.innerHTML = '';
                        resultsContainer.innerHTML = '';
                        updateStats();

                        btnStart.disabled = true;
                        btnStop.disabled = false;

                        addLog('开始批量注册：数量 ' + count + '，并发数 ' + concurrency + '，域名 ' + domain, 'info');
                        if (proxies.length) {
                            addLog('已加载代理数量：' + proxies.length, 'info');
                        }

                        try {
                            const results = await window.hotmailBatchAPI.batchRegister({
                                count,
                                concurrency,
                                domain,
                                proxies,
                                onProgress: function (evt) {
                                    if (evt && evt.message) {
                                        addLog(evt.message, evt.type || 'info');
                                    }
                                },
                                onResult: function (result) {
                                    const row = document.createElement('div');
                                    row.style.marginBottom = '4px';

                                    if (result.success) {
                                        row.style.color = '#4caf50';
                                        row.textContent = (result.index || '') + ' ✔ ' + (result.email || '(未知邮箱)');
                                        stats.success += 1;
                                        if (result.refreshToken || result.tokenLine) {
                                            stats.token += 1;
                                        }
                                        successfulAccounts.push(result);
                                    } else {
                                        row.style.color = '#e06c75';
                                        row.textContent = (result.index || '') + ' ✘ ' + (result.email || '(未知邮箱)') +
                                            ' —— ' + (result.error || '未知错误');
                                        stats.failed += 1;
                                    }

                                    resultsContainer.appendChild(row);
                                    updateStats();
                                }
                            });

                            addLog('批量注册完成，总计处理 ' + results.length + ' 个账号。', 'success');
                        } catch (err) {
                            console.error('批量注册异常:', err);
                            addLog('批量注册异常：' + (err && err.message ? err.message : String(err)), 'error');
                        } finally {
                            isRunning = false;
                            btnStart.disabled = false;
                            btnStop.disabled = true;
                        }
                    });

                    btnStop.addEventListener('click', function () {
                        alert('当前版本暂不支持中途强制停止，将在本轮任务结束后自动停止。');
                    });

                    btnExport.addEventListener('click', function () {
                        const accountsWithToken = successfulAccounts.filter(function (acc) {
                            return acc.tokenLine || acc.refreshToken;
                        });

                        if (!accountsWithToken.length) {
                            alert('没有可导出的账号（需要有 refresh_token）。');
                            return;
                        }

                        const content = accountsWithToken
                            .map(function (acc) {
                                if (acc.tokenLine) return acc.tokenLine;
                                return (acc.email || '') + '|' + (acc.refreshToken || '');
                            })
                            .join('\n');

                        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'hotmail_tokens_' + Date.now() + '.txt';
                        a.click();
                        URL.revokeObjectURL(url);

                        addLog('已导出 ' + accountsWithToken.length + ' 个账号的 Token。', 'success');
                    });

                    btnClear.addEventListener('click', function () {
                        if (!confirm('确定要清空所有结果吗？')) return;
                        successfulAccounts = [];
                        stats = { total: 0, success: 0, failed: 0, token: 0 };
                        logContainer.innerHTML = '';
                        resultsContainer.innerHTML = '<p style="color:#888;text-align:center;">暂无数据</p>';
                        updateStats();
                    });

                    // 初始化代理数量显示
                    getProxies();
                    updateStats();

                    console.log('Hotmail 批量注册工具脚本初始化完成。');
                })();
            </script>
        `
    },

    'ms-graph-oauth': {
        title: '🔑 微软账号授权',
        html: `
            <div class="tool-content">
                <div class="section">
                    <h3>获取Microsoft账号的Refresh Token</h3>
                    <p style="color: #888; font-size: 14px; margin-bottom: 20px;">
                        此工具使用设备代码流(Device Code Flow)获取Microsoft账号的refresh_token，可用于邮箱API访问
                    </p>
                </div>

                <div class="section">
                    <label>Client ID (应用程序ID)</label>
                    <input type="text" id="ms-client-id" value="1d08522d-70bb-4128-8684-449f9a2efa5f" placeholder="输入你的Azure AD应用Client ID">
                    <small style="display: block; margin-top: 5px; color: #888;">
                        默认值为示例Client ID，建议使用自己的Azure AD应用
                    </small>
                </div>

                <div class="section">
                    <label>邮箱地址 (可�?</label>
                    <input type="email" id="ms-email-input" placeholder="example@outlook.com">
                    <small style="display: block; margin-top: 5px; color: #888;">
                        用于标识此token，会包含在输出结果中
                    </small>
                </div>

                <div class="section">
                    <label>OAuth Scope</label>
                    <input type="text" id="ms-oauth-scope" value="offline_access https://graph.microsoft.com/Mail.Read" placeholder="OAuth权限范围">
                    <small style="display: block; margin-top: 5px; color: #888;">
                        默认权限：离线访�?+ 邮件读取
                    </small>
                </div>

                <div class="section">
                    <button id="btn-start-ms-auth" class="primary-btn">开始授�?/button>
                    <button id="btn-cancel-ms-auth" class="secondary-btn" disabled>取消授权</button>
                </div>

                <div class="section" id="ms-auth-status" style="display: none;">
                    <div style="padding: 15px; background: #e3f2fd; border-radius: 8px; border-left: 4px solid #2196F3;">
                        <h4 style="margin: 0 0 10px 0; color: #1976D2;">📋 授权步骤�?/h4>
                        <div id="ms-auth-message" style="white-space: pre-wrap; font-family: monospace; color: #333; line-height: 1.6;"></div>
                        <div style="margin-top: 10px;">
                            <button id="btn-open-verification-url" class="secondary-btn" style="margin-right: 10px;">打开授权网页</button>
                            <button id="btn-copy-user-code" class="secondary-btn">复制验证�?/button>
                        </div>
                    </div>
                    <div style="margin-top: 10px; padding: 10px; background: #fff3cd; border-radius: 4px; color: #856404;">
                        <strong>�?等待授权�?..</strong> 请在浏览器中完成登录和授权操�?
                    </div>
                </div>

                <div class="section">
                    <h4>生成的Refresh Token</h4>
                    <textarea id="ms-token-output" rows="6" readonly placeholder="授权成功后，refresh_token将显示在这里..." style="font-family: monospace; font-size: 12px;"></textarea>
                    <div style="margin-top: 10px;">
                        <button id="btn-copy-token" class="secondary-btn">复制Token</button>
                        <button id="btn-save-token" class="secondary-btn">保存到文�?/button>
                        <button id="btn-clear-token" class="secondary-btn">清空</button>
                    </div>
                </div>

                <div class="section">
                    <h4>授权历史记录</h4>
                    <div id="ms-token-history" style="max-height: 200px; overflow-y: auto; background: rgba(0,0,0,0.05); padding: 10px; border-radius: 4px;">
                        <p style="color: #888; text-align: center;">暂无记录</p>
                    </div>
                </div>
            </div>

            <script>
                (function() {
                    const btnStart = document.getElementById('btn-start-ms-auth');
                    const btnCancel = document.getElementById('btn-cancel-ms-auth');
                    const btnOpenUrl = document.getElementById('btn-open-verification-url');
                    const btnCopyCode = document.getElementById('btn-copy-user-code');
                    const btnCopyToken = document.getElementById('btn-copy-token');
                    const btnSaveToken = document.getElementById('btn-save-token');
                    const btnClearToken = document.getElementById('btn-clear-token');
                    const statusDiv = document.getElementById('ms-auth-status');
                    const messageDiv = document.getElementById('ms-auth-message');
                    const outputArea = document.getElementById('ms-token-output');
                    const historyDiv = document.getElementById('ms-token-history');

                    let currentDeviceCode = null;
                    let currentVerificationUri = null;
                    let currentUserCode = null;
                    let isPolling = false;

                    // Load history from localStorage
                    function loadHistory() {
                        const history = JSON.parse(localStorage.getItem('msTokenHistory') || '[]');
                        if (history.length === 0) {
                            historyDiv.innerHTML = '<p style="color: #888; text-align: center;">暂无记录</p>';
                            return;
                        }
                        historyDiv.innerHTML = history.map((item, idx) => 
                            '<div style="padding: 8px; margin-bottom: 5px; background: white; border-radius: 4px; border-left: 3px solid #4CAF50;">' +
                                '<strong>' + (idx + 1) + '. ' + (item.email || '未指定邮箱') + '</strong>' +
                                '<small style="display: block; color: #666;">时间: ' + item.time + '</small>' +
                                '<small style="display: block; color: #666; font-family: monospace; overflow: hidden; text-overflow: ellipsis;">Token: ' + item.token.substring(0, 50) + '...</small>' +
                            '</div>'
                        ).join('');
                    }

                    function saveToHistory(email, token) {
                        const history = JSON.parse(localStorage.getItem('msTokenHistory') || '[]');
                        history.unshift({
                            email: email || '未指�?,
                            token: token,
                            time: new Date().toLocaleString()
                        });
                        if (history.length > 10) history.pop();
                        localStorage.setItem('msTokenHistory', JSON.stringify(history));
                        loadHistory();
                    }

                    loadHistory();

                    btnStart.addEventListener('click', async () => {
                        // 检查API是否可用
                        if (!window.msGraphAPI) {
                            alert('�?微软授权功能模块未加载，请检查依赖是否安装完�?);
                            return;
                        }

                        const clientId = document.getElementById('ms-client-id').value.trim();
                        const email = document.getElementById('ms-email-input').value.trim();
                        const scope = document.getElementById('ms-oauth-scope').value.trim();

                        if (!clientId) {
                            alert('请输入Client ID');
                            return;
                        }

                        try {
                            btnStart.disabled = true;
                            btnCancel.disabled = false;
                            statusDiv.style.display = 'block';
                            messageDiv.textContent = '正在请求授权�?..';

                            // Call preload exposed API
                            const dcResult = await window.msGraphAPI.startDeviceCode({ clientId, scope });

                            currentDeviceCode = dcResult.device_code;
                            currentVerificationUri = dcResult.verification_uri;
                            currentUserCode = dcResult.user_code;

                            messageDiv.textContent = dcResult.message || 
                                '请访问 ' + dcResult.verification_uri + '\n并输入代码: ' + dcResult.user_code;

                            // Start polling
                            isPolling = true;
                            pollForToken(clientId, dcResult.device_code, dcResult.interval, dcResult.expires_in, email);

                        } catch (err) {
                            console.error('启动授权流程失败:', err);
                            alert('启动授权失败: ' + err.message);
                            btnStart.disabled = false;
                            btnCancel.disabled = true;
                            statusDiv.style.display = 'none';
                        }
                    });

                    async function pollForToken(clientId, deviceCode, interval, expiresIn, email) {
                        try {
                            const result = await window.msGraphAPI.pollForToken({
                                clientId,
                                deviceCode,
                                interval,
                                expiresIn,
                                email
                            });

                            if (!isPolling) return;

                            // Success
                            outputArea.value = result.line;
                            statusDiv.style.display = 'none';
                            btnStart.disabled = false;
                            btnCancel.disabled = true;
                            isPolling = false;

                            saveToHistory(email, result.line);
                            alert('�?授权成功！Refresh Token 已生�?);

                        } catch (err) {
                            if (!isPolling) return;
                            
                            console.error('获取Token失败:', err);
                            alert('获取Token失败: ' + err.message);
                            statusDiv.style.display = 'none';
                            btnStart.disabled = false;
                            btnCancel.disabled = true;
                            isPolling = false;
                        }
                    }

                    btnCancel.addEventListener('click', () => {
                        isPolling = false;
                        statusDiv.style.display = 'none';
                        btnStart.disabled = false;
                        btnCancel.disabled = true;
                        messageDiv.textContent = '';
                    });

                    btnOpenUrl.addEventListener('click', () => {
                        if (currentVerificationUri) {
                            window.msGraphAPI.openExternal(currentVerificationUri);
                        }
                    });

                    btnCopyCode.addEventListener('click', async () => {
                        if (currentUserCode) {
                            try {
                                await navigator.clipboard.writeText(currentUserCode);
                                alert('验证码已复制: ' + currentUserCode);
                            } catch (e) {
                                alert('验证�? ' + currentUserCode);
                            }
                        }
                    });

                    btnCopyToken.addEventListener('click', async () => {
                        const text = outputArea.value.trim();
                        if (!text) {
                            alert('没有可复制的内容');
                            return;
                        }
                        try {
                            await navigator.clipboard.writeText(text);
                            alert('已复制到剪贴�?);
                        } catch (e) {
                            alert('复制失败，请手动复制');
                        }
                    });

                    btnSaveToken.addEventListener('click', () => {
                        const text = outputArea.value.trim();
                        if (!text) {
                            alert('没有可保存的内容');
                            return;
                        }
                        const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = ms_refresh_token_' + Date.now() + '.txt;
                        a.click();
                        URL.revokeObjectURL(url);
                    });

                    btnClearToken.addEventListener('click', () => {
                        outputArea.value = '';
                    });
                })();
            </script>
        `
    },

    '5sim-sms-verification': {
        title: '📱 5SIM短信验证',
        html: `
            <div class="tool-workspace">
                <!-- Top Bar -->
                <div class="workspace-header">
                    <div class="header-tabs">
                        <button class="header-tab active" data-tab="fivesim-generate">生成号码</button>
                        <button class="header-tab" data-tab="fivesim-settings">API设置</button>
                        <span class="tab-indicator">已生�? <span id="fivesim-count">0</span></span>
                    </div>
                    <div class="header-actions">
                        <span class="platform-badge">5SIM API</span>
                    </div>
                </div>

                <!-- Tab Content: Generate Numbers -->
                <div class="tab-content active" id="tab-fivesim-generate">
                    <div class="content-section">
                        <h3 class="section-title">生成虚拟号码</h3>
                        <div class="form-grid">
                            <div class="form-item">
                                <label>国家(country)</label>
                                <select id="fivesim-country">
                                    <option value="usa">USA (美国)</option>
                                    <option value="england">England (英国)</option>
                                    <option value="canada">Canada (加拿�?</option>
                                    <option value="0">任意国家</option>
                                </select>
                            </div>
                            <div class="form-item">
                                <label>服务(service)</label>
                                <input type="text" id="fivesim-service" placeholder="例如 amazon / other / ot" value="amazon">
                            </div>
                            <div class="form-item">
                                <label>运营�?operator)</label>
                                <select id="fivesim-operator">
                                    <option value="any">任意</option>
                                    <option value="virtual">virtual</option>
                                    <option value="virtual18">virtual18</option>
                                    <option value="virtual60">virtual60</option>
                                </select>
                            </div>
                            <div class="form-item">
                                <label>生成数量</label>
                                <input type="number" id="fivesim-count-input" min="1" max="20" value="3">
                            </div>
                        </div>
                        <button class="btn btn-generate" id="btn-generate-fivesim">生成配置</button>
                        <div id="fivesim-status" style="margin-top: 10px; color: var(--text-gray);"></div>
                    </div>

                    <!-- Results Display -->
                    <div class="content-section" style="margin-top: 20px;">
                        <h3 class="section-title">结果(每一行就是一�?手机+api数据")</h3>
                        <textarea id="fivesim-output" spellcheck="false" placeholder="+1*******----http://api1.5sim.net/stubs/handler_api.php?..." style="width: 100%; min-height: 200px; background: rgba(0,0,0,0.3); color: var(--text-light); border: 1px solid rgba(102, 126, 234, 0.3); border-radius: 8px; padding: 15px; font-family: monospace; font-size: 13px; resize: vertical;"></textarea>
                        <div style="margin-top: 10px;">
                            <button class="btn btn-action" id="btn-copy-fivesim">复制全部到剪贴板</button>
                        </div>
                    </div>
                </div>

                <!-- Tab Content: API Settings -->
                <div class="tab-content" id="tab-fivesim-settings" style="display: none;">
                    <div class="content-section">
                        <h3 class="section-title">API配置</h3>
                        <div class="form-item" style="max-width: 600px;">
                            <label>API1 协议 api_key (Deprecated API)</label>
                            <input type="text" id="fivesim-apikey" placeholder="�?5SIM 个人中心�?API key API1 protocol 那一�? style="width: 100%;">
                            <small style="display: block; margin-top: 5px; color: var(--text-gray);">
                                提示: API Key 会自动保存到本地，下次打开会自动加�?
                            </small>
                        </div>
                        <div style="margin-top: 15px;">
                            <button class="btn btn-action" id="btn-save-fivesim-apikey">保存 API Key</button>
                            <button class="btn btn-action" id="btn-clear-fivesim-apikey">清除 API Key</button>
                        </div>
                    </div>
                </div>
            </div>
        `
    }
};

// Export tool content getter
function getToolContent(toolName) {
    return toolDefinitions[toolName] || {
        title: '工具未找到',
        html: '<p>该工具暂未实现</p>'
    };
}

// Export for use in main.js
console.log('=== tools.js: 准备导出 getToolContent 函数 ===');
console.log('window 对象存在:', typeof window !== 'undefined');
console.log('toolDefinitions 包含的工具:', Object.keys(toolDefinitions));

if (typeof window !== 'undefined') {
    window.getToolContent = getToolContent;
    console.log('✅ window.getToolContent 已设置');
    console.log('验证: window.getToolContent 类型:', typeof window.getToolContent);
} else {
    console.error('❌ window 对象不存在，无法导出函数');
}

console.log('=== tools.js 加载完成 ===');
