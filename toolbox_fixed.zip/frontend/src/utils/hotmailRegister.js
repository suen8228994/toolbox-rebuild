// src/utils/hotmailRegister.js
// Hotmail/Outlook 批量注册工具

const axios = require("axios");
const crypto = require("crypto");

/**
 * 生成随机字符串
 */
function randomString(length = 8) {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * 生成随机邮箱名
 */
function generateEmailName() {
  const prefix = randomString(6);
  const suffix = randomString(4);
  return `${prefix}${suffix}`;
}

/**
 * 生成随机密码
 */
function generatePassword(length = 12) {
  const lowercase = "abcdefghijklmnopqrstuvwxyz";
  const uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const numbers = "0123456789";
  const symbols = "!@#$%";
  
  const allChars = lowercase + uppercase + numbers + symbols;
  let password = "";
  
  // 确保至少包含每种类型的字符
  password += lowercase.charAt(Math.floor(Math.random() * lowercase.length));
  password += uppercase.charAt(Math.floor(Math.random() * uppercase.length));
  password += numbers.charAt(Math.floor(Math.random() * numbers.length));
  password += symbols.charAt(Math.floor(Math.random() * symbols.length));
  
  // 填充剩余长度
  for (let i = password.length; i < length; i++) {
    password += allChars.charAt(Math.floor(Math.random() * allChars.length));
  }
  
  // 打乱顺序
  return password.split('').sort(() => Math.random() - 0.5).join('');
}

/**
 * 生成随机姓名
 */
function generateName() {
  const firstNames = [
    "James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph",
    "Thomas", "Charles", "Mary", "Patricia", "Jennifer", "Linda", "Elizabeth",
    "Barbara", "Susan", "Jessica", "Sarah", "Karen"
  ];
  
  const lastNames = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
    "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
    "Thomas", "Taylor", "Moore", "Jackson", "Martin"
  ];
  
  const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
  const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
  
  return { firstName, lastName };
}

/**
 * 生成随机生日（18-60岁）
 */
function generateBirthDate() {
  const today = new Date();
  const minAge = 18;
  const maxAge = 60;
  
  const year = today.getFullYear() - minAge - Math.floor(Math.random() * (maxAge - minAge));
  const month = Math.floor(Math.random() * 12) + 1;
  const day = Math.floor(Math.random() * 28) + 1; // 简化处理，使用28天
  
  return {
    year: year.toString(),
    month: month.toString(),
    day: day.toString()
  };
}

/**
 * 模拟注册 Hotmail/Outlook 账号
 * 注意：此为示例实现，实际需要根据Microsoft最新API调整
 * 
 * @param {Object} options
 * @param {string} [options.domain] - 邮箱域名，默认 'outlook.com'
 * @param {string} [options.proxy] - 代理配置 'host:port:user:pass'
 * @param {function} [options.onProgress] - 进度回调
 * @returns {Promise<{email: string, password: string, success: boolean, error?: string}>}
 */
async function registerHotmail(options = {}) {
  const { domain = "outlook.com", proxy, onProgress } = options;
  
  try {
    // 生成账号信息
    const emailName = generateEmailName();
    const email = `${emailName}@${domain}`;
    const password = generatePassword();
    const { firstName, lastName } = generateName();
    const birthDate = generateBirthDate();
    
    if (onProgress) onProgress({ step: "生成账号信息", email });
    
    // 配置axios实例
    const axiosConfig = {
      timeout: 30000,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "application/json",
        "Content-Type": "application/json"
      }
    };
    
    // 如果有代理配置
    if (proxy) {
      const [host, port, username, proxyPassword] = proxy.split(':');
      if (host && port) {
        axiosConfig.proxy = {
          host,
          port: parseInt(port),
          ...(username && proxyPassword ? { auth: { username, password: proxyPassword } } : {})
        };
      }
    }
    
    const client = axios.create(axiosConfig);
    
    if (onProgress) onProgress({ step: "准备注册", email });
    
    // ============================================
    // 注意：以下是简化的模拟流程
    // 实际Microsoft注册流程非常复杂，包括：
    // 1. 获取注册页面和CSRF token
    // 2. 检查邮箱可用性
    // 3. 提交注册信息
    // 4. 验证码处理（可能需要第三方打码服务）
    // 5. 手机验证（如果需要）
    // ============================================
    
    // 模拟延迟
    await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 3000));
    
    if (onProgress) onProgress({ step: "注册中", email });
    
    // 实际实现需要：
    // 1. 访问 https://signup.live.com/
    // 2. 获取必要的tokens和cookies
    // 3. 提交注册表单
    // 4. 处理验证流程
    
    // 这里模拟随机成功/失败（实际应该调用真实API）
    const simulateSuccess = Math.random() > 0.3; // 70%成功率用于演示
    
    if (!simulateSuccess) {
      throw new Error("邮箱名已被使用或注册失败");
    }
    
    if (onProgress) onProgress({ step: "注册成功", email });
    
    return {
      email,
      password,
      firstName,
      lastName,
      birthDate: `${birthDate.year}-${birthDate.month}-${birthDate.day}`,
      success: true
    };
    
  } catch (error) {
    return {
      email: null,
      password: null,
      success: false,
      error: error.message || "注册失败"
    };
  }
}

/**
 * 批量注册账号
 * @param {Object} options
 * @param {number} options.count - 注册数量
 * @param {number} [options.concurrency] - 并发数，默认3
 * @param {string} [options.domain] - 邮箱域名
 * @param {Array<string>} [options.proxies] - 代理列表
 * @param {function} [options.onProgress] - 进度回调
 * @param {function} [options.onResult] - 单个结果回调
 * @returns {Promise<Array>}
 */
async function batchRegister(options) {
  const {
    count,
    concurrency = 3,
    domain = "outlook.com",
    proxies = [],
    onProgress,
    onResult
  } = options;
  
  const results = [];
  const queue = [];
  
  // 创建任务队列
  for (let i = 0; i < count; i++) {
    queue.push(i);
  }
  
  // 并发执行
  const workers = [];
  for (let i = 0; i < concurrency; i++) {
    workers.push(
      (async () => {
        while (queue.length > 0) {
          const index = queue.shift();
          if (index === undefined) break;
          
          // 选择代理（轮询）
          const proxy = proxies.length > 0 ? proxies[index % proxies.length] : null;
          
          if (onProgress) {
            onProgress({
              type: "info",
              message: `开始注册第 ${index + 1}/${count} 个账号...`
            });
          }
          
          // 执行注册
          const result = await registerHotmail({
            domain,
            proxy,
            onProgress: (progress) => {
              if (onProgress) {
                onProgress({
                  type: "info",
                  message: `[${index + 1}] ${progress.step}: ${progress.email || ""}`
                });
              }
            }
          });
          
          result.index = index + 1;
          results.push(result);
          
          // 回调单个结果
          if (onResult) {
            onResult(result);
          }
          
          if (onProgress) {
            if (result.success) {
              onProgress({
                type: "success",
                message: `✓ [${index + 1}] 注册成功: ${result.email}`
              });
            } else {
              onProgress({
                type: "error",
                message: `✗ [${index + 1}] 注册失败: ${result.error}`
              });
            }
          }
          
          // 延迟避免频率限制
          await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
        }
      })()
    );
  }
  
  await Promise.all(workers);
  
  return results;
}

module.exports = {
  registerHotmail,
  batchRegister,
  generateEmailName,
  generatePassword,
  generateName,
  generateBirthDate
};
