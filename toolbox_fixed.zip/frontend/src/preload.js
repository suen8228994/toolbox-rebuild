// Preload script - with sandbox disabled
const { contextBridge, shell } = require('electron');
const path = require('path');

console.log('=== Preload script loaded ===');
console.log('__dirname:', __dirname);

// Load modules (sandbox must be disabled in main.js)
let msGraphModule, hotmailModule;
try {
  const msGraphPath = path.join(__dirname, 'utils', 'msGraphDeviceCode.js');
  const hotmailPath = path.join(__dirname, 'utils', 'hotmailRegister.js');
  
  console.log('尝试加载模块:');
  console.log('  - msGraphPath:', msGraphPath);
  console.log('  - hotmailPath:', hotmailPath);
  
  msGraphModule = require(msGraphPath);
  console.log('  ✅ msGraphModule loaded, exports:', Object.keys(msGraphModule));
  
  hotmailModule = require(hotmailPath);
  console.log('  ✅ hotmailModule loaded, exports:', Object.keys(hotmailModule));
  
  console.log('✅ All modules loaded successfully!');
} catch (err) {
  console.error('❌ Failed to load modules:');
  console.error('  Error:', err.message);
  console.error('  Stack:', err.stack);
  // 使用空实现，不影响其他功能
  msGraphModule = { startDeviceCodeFlow: null, pollForRefreshToken: null };
  hotmailModule = { batchRegister: null };
}

// Expose MS Graph API
console.log('正在暴露 msGraphAPI 到 window...');
contextBridge.exposeInMainWorld('msGraphAPI', {
  startDeviceCode: async ({ clientId, scope }) => {
    console.log('msGraphAPI.startDeviceCode called');
    if (!msGraphModule || !msGraphModule.startDeviceCodeFlow) {
      throw new Error('MS Graph module not available');
    }
    return await msGraphModule.startDeviceCodeFlow({ clientId, scope });
  },
  
  pollForToken: async ({ clientId, deviceCode, interval, expiresIn, email }) => {
    console.log('msGraphAPI.pollForToken called');
    if (!msGraphModule || !msGraphModule.pollForRefreshToken) {
      throw new Error('MS Graph module not available');
    }
    return await msGraphModule.pollForRefreshToken({ clientId, deviceCode, interval, expiresIn, email });
  },
  
  openExternal: (url) => {
    console.log('msGraphAPI.openExternal called:', url);
    shell.openExternal(url);
  }
});
console.log('✅ msGraphAPI exposed');

// Expose Hotmail Batch Registration API
console.log('正在暴露 hotmailBatchAPI 到 window...');
contextBridge.exposeInMainWorld('hotmailBatchAPI', {
  batchRegister: async (options) => {
    console.log('hotmailBatchAPI.batchRegister called with options:', options);
    if (!hotmailModule || !hotmailModule.batchRegister) {
      throw new Error('Hotmail module not available');
    }
    return await hotmailModule.batchRegister(options);
  }
});
console.log('✅ hotmailBatchAPI exposed');

console.log('=== Preload script完成 ===');

